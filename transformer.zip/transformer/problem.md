for_list,wl1_ratio[id],all_param[id]

